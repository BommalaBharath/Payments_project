package com.payment.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="customer")
public class Customer {
	@Id
	String account_number;
	String name;
	double clear_balance;
	String overdraft;
	public String getAccount_number() {
		return account_number;
	}
	public void setAccount_number(String account_number) {
		this.account_number = account_number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getClear_balance() {
		return clear_balance;
	}
	public void setClear_balance(double clear_balance) {
		this.clear_balance = clear_balance;
	}
	public String getOverdraft() {
		return overdraft;
	}
	public void setOver_draft(String over_draft) {
		this.overdraft = over_draft;
	}
	@Override
	public String toString() {
		return "Customer [account_number=" + account_number + ", name=" + name + ", clear_balance=" + clear_balance
				+ ", over_draft=" + overdraft + "]";
	}
	

}
